
public class Test4String {
	public void compareTo() {}
	public void concat() {}
	public void compareTo2() {}
	public void concat2() {}
	public void compareTo3() {}
	public void concat3() {}
}

class TestABC {
	Test4String ts = new Test4String();
	//ts.concat3();
}







