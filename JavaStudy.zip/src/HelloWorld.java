
public class HelloWorld {

	public static void main(String[] args) {
		System.out.println("이클립스 첫 실행");
		System.out.println("Hello Eclipse");
	}
}
