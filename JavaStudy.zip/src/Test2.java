
public class Test2 {

	public static void main(String[] args) {
		
		//정수형
		int a = 10;
		//실수형
		double b = 3.14;
		
		double c = 9; //자동형변환
		int d = (int) 1.0; //강제형변환 

	}

}
