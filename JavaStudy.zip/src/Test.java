
public class Test {

	public static void main(String[] args) {
		int a = 10;
		int a2 = 99;
		f1();
		f2();
		f3();
	}
	
	static void f1() {}
	static void f2() {}
	static void f3() {}
}
