
public class Test3 {

	public static void main(String[] args) {
		
		System.out.println("0번:"+args[0]);
		System.out.println("1번:"+args[1]);

	}

}
